(function(){

  "use strict";

  app.run(['$rootScope', 'signalRSvc', function ($rootScope, signalRSvc) {

  }]);
}());

