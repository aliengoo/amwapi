(function () {
  "use strict";

  window.app = angular.module('app', [
    'ngResource',
    'ngCookies',
    'ngAnimate',
    'fx.animations',
    'ui.router',
    'ui.utils',
    'ui.bootstrap',
    'chieffancypants.loadingBar',
    'cfp.hotkeys',
    'LocalStorageModule']);
}());;(function(){
  app.config([
    '$provide',
    '$stateProvider',
    '$urlRouterProvider',
    'cfpLoadingBarProvider',
    'localStorageServiceProvider', function (
      $provide,
      $stateProvider,
      $urlRouterProvider,
      cfpLoadingBarProvider,
      localStorageServiceProvider) {

    // TODO : Uncomment to disable the spinner
    //cfpLoadingBarProvider.includeSpinner = false;


    // TODO : Set the prefix for local storage
    // localStorageServiceProvider.setPrefix('newPrefix');

    // TODO : Handle uncaught exceptions here
    $provide.decorator("$exceptionHandler", ['$delegate', '$injector', function ($delegate, $injector) {
      return function (exception, cause) {
        $delegate(exception, cause);

        var rootScope = $injector.get('$rootScope');

        rootScope.$broadcast('uncaughtException', {
          exception: exception,
          cause: cause
        });

        // TODO : Add logic here to process uncaught exceptions, or wire up a listener
      };
    }]);

    // TODO : Specify some routes
    $urlRouterProvider.otherwise('/home');

    $stateProvider.state('home', {
      url: '/home',
      templateUrl: 'public/html/home/home.html',
      controller: 'homeCtrl'
    });
  }]);
}());





;(function(){

  "use strict";

  app.run(['$rootScope', 'signalRSvc', function ($rootScope, signalRSvc) {

  }]);
}());

;(function () {

  "use strict";

  app.factory('helloWorldHub', ['$rootScope', '$log', '$q', 'signalRSvc', function ($rootScope, $log, $q, signalRSvc) {

    var self = this;

    self.that = undefined;

    return {
      init: function () {

        var d = $q.defer();

        if (!self.that) {
          signalRSvc.create('helloWorldHub', function(hub){

            // TODO : methods and handlers get added here...
            hub.on('acceptGreet', function (message) {
              $rootScope.$broadcast('acceptGreet', message);
            });

            self.that = {
              greetAll: function () {
                hub.invoke('greetAll');
              }
            };

          }).then(function () {
            d.resolve(self.that);
          }, function (error) {

            d.reject(error);
          });
        } else {
          d.resolve(self.that);
        }

        return d.promise;
      }
    };

  }]);

}());

;(function () {

  "use strict";

  app.factory('signalRSvc', ['$rootScope', '$log', '$q', function ($rootScope, $log, $q) {

    var connection = $.hubConnection('signalR');

    connection.logging = true;

    var hubs = {};

    var that = {
      hubs : {},
      start : function(){
        var d = $q.defer();

        //Starting connection
        connection.start().done(function () {
          d.resolve(connection);
        }).fail(function (err) {
          d.reject(err);
        });

        return d.promise;
      },
      create: function (hubName, extend) {
        if (hubs.hasOwnProperty(hubName)){
          return $q.when(hubs[hubName]);
        }

        if (!extend) {
          throw Error("extend argument required");
        }

        hubs[hubName] = connection.createHubProxy(hubName);

        extend(hubs[hubName]);

        if ($.signalR.connectionState.connected){
          connection.stop();
        }

        var d = $q.defer();

        this.start().then(function(){
          d.resolve(hubs[hubName]);
        }, function(error) {
          d.reject(error);
        });

        return d.promise;
      }
    };

    return {
      start : that.start,
      create : that.create
    };
  }]);

}());
;(function () {

  "use strict";

  app.controller('homeCtrl', ['$rootScope', '$scope', 'helloWorldHub', function ($rootScope, $scope, helloWorldHub) {
    $scope.$on('acceptGreet', function (ev, message) {
      $scope.message = message || 'No message';
    });

    helloWorldHub.init().then(function (hub) {
      hub.greetAll();
    });

  }]);

}());
