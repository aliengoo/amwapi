# A Visual Studio project template.

## AngularJS, MongoDB and Web API

I like these things, but I like thinks like grunt and bower as well.  This was about bringing it all together.